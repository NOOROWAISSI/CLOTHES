import http from 'k6/http';
import { check, sleep } from 'k6';

const BASE = 'https://localhost:8081/api/v1';
const TOKEN = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1laWRlbnRpZmllciI6IjEwMDIiLCJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9lbWFpbGFkZHJlc3MiOiJub29yQGdtYWlsLmNvbSIsImh0dHA6Ly9zY2hlbWFzLnhtbHNvYXAub3JnL3dzLzIwMDUvMDUvaWRlbnRpdHkvY2xhaW1zL25hbWUiOiJub28iLCJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dzLzIwMDgvMDYvaWRlbnRpdHkvY2xhaW1zL3JvbGUiOiJhZG1pbiIsImV4cCI6MTc3NjgxMzk0NiwiaXNzIjoiV2FzZWxBUEkiLCJhdWQiOiJXYXNlbENsaWVudCJ9.BwMXNr4jXNybJuyPXzPHeypOEel8u1u1UJ56ddGu5X8';

export let options = {
  vus: 10,
  duration: '20s',
};

export default function () {

  let payload = JSON.stringify({
    title: `Incident ${Math.random()}`,
    description: "k6 load test",
    type: "accident",
    severity: "low",
    checkpointId: 1
  });

  let res = http.post(`${BASE}/incident`, payload, {
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${TOKEN}`,
    },
  });

  check(res, {
    'created': (r) => r.status === 200 || r.status === 201,
  });

  sleep(1);
}