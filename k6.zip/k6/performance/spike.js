import http from 'k6/http';
import { sleep, check } from 'k6';

const BASE = 'https://localhost:8081/api/v1';
const TOKEN = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1laWRlbnRpZmllciI6IjEwMDIiLCJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9lbWFpbGFkZHJlc3MiOiJub29yQGdtYWlsLmNvbSIsImh0dHA6Ly9zY2hlbWFzLnhtbHNvYXAub3JnL3dzLzIwMDUvMDUvaWRlbnRpdHkvY2xhaW1zL25hbWUiOiJub28iLCJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dzLzIwMDgvMDYvaWRlbnRpdHkvY2xhaW1zL3JvbGUiOiJhZG1pbiIsImV4cCI6MTc3NjgxMzk0NiwiaXNzIjoiV2FzZWxBUEkiLCJhdWQiOiJXYXNlbENsaWVudCJ9.BwMXNr4jXNybJuyPXzPHeypOEel8u1u1UJ56ddGu5X8';

const headers = {
  Authorization: `Bearer ${TOKEN}`,
};

export let options = {
  stages: [
    { duration: '10s', target: 5 },
    { duration: '10s', target: 50 }, // spike 🔥
    { duration: '10s', target: 5 },
  ],
};

export default function () {

  let users = http.get(`${BASE}/users`, { headers });
  check(users, { 'users 200': r => r.status === 200 });

  let incidents = http.get(`${BASE}/incident`, { headers });
  check(incidents, { 'incidents 200': r => r.status === 200 });

  let reports = http.get(`${BASE}/reports`, { headers });
  check(reports, { 'reports 200': r => r.status === 200 });

  sleep(1);
}