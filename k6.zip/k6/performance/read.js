import http from 'k6/http';
import { check, sleep } from 'k6';

const BASE = 'https://localhost:8081/api/v1';
const TOKEN = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1laWRlbnRpZmllciI6IjEwMDIiLCJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9lbWFpbGFkZHJlc3MiOiJub29yQGdtYWlsLmNvbSIsImh0dHA6Ly9zY2hlbWFzLnhtbHNvYXAub3JnL3dzLzIwMDUvMDUvaWRlbnRpdHkvY2xhaW1zL25hbWUiOiJub28iLCJodHRwOi8vc2NoZW1hcy5taWNyb3NvZnQuY29tL3dzLzIwMDgvMDYvaWRlbnRpdHkvY2xhaW1zL3JvbGUiOiJhZG1pbiIsImV4cCI6MTc3NjgxMzk0NiwiaXNzIjoiV2FzZWxBUEkiLCJhdWQiOiJXYXNlbENsaWVudCJ9.BwMXNr4jXNybJuyPXzPHeypOEel8u1u1UJ56ddGu5X8';

export let options = {
  vus: 10,
  duration: '20s',
};

const headers = {
  Authorization: `Bearer ${TOKEN}`,
};

export default function () {

  const endpoints = [
    `${BASE}/incident`,
    `${BASE}/reports`,
    `${BASE}/routes/all`,
    `${BASE}/subscription`,
    `${BASE}/users`,
    `${BASE}/checkpoint`,
    `${BASE}/alerts/subscribers/2`
  ];

  endpoints.forEach(url => {
    let res = http.get(url, { headers });

   

    check(res, {
      'status is 200': (r) => r.status === 200,
    });
  });

  sleep(1);
}